// Copies index.html into dist/ (asset paths already match the minified output).
const fs = require("fs");
fs.mkdirSync("dist", { recursive: true });
fs.writeFileSync("dist/index.html", fs.readFileSync("index.html", "utf8"));
console.log("Built dist/");
