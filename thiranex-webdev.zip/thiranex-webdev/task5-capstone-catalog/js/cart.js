let cart = {};
try { cart = JSON.parse(localStorage.getItem("cart")) || {}; } catch {}
const persist = () => { try { localStorage.setItem("cart", JSON.stringify(cart)); } catch {} };
export const items = () => Object.entries(cart).map(([id, qty]) => ({ id: +id, qty }));
export const count = () => items().reduce((n, i) => n + i.qty, 0);
export const add = (id) => { cart[id] = (cart[id] || 0) + 1; persist(); };
export const remove = (id) => { delete cart[id]; persist(); };
