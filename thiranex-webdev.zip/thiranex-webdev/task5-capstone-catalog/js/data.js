const img = (bg, label) => "data:image/svg+xml," + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="400" height="300" fill="${bg}"/><text x="200" y="160" font-size="28" text-anchor="middle" fill="#fff" font-family="sans-serif">${label}</text></svg>`);
export const products = [
  { id: 1, name: "Walnut Serving Board", category: "Kitchen", price: 42, desc: "Hand-turned walnut with a food-safe oil finish.", image: img("#7a4e2d", "Walnut Board") },
  { id: 2, name: "Linen Table Runner", category: "Textiles", price: 28, desc: "Stonewashed linen, 180 cm long.", image: img("#8a8f6a", "Linen Runner") },
  { id: 3, name: "Ceramic Pour-over Set", category: "Kitchen", price: 55, desc: "Dripper and carafe in speckled glaze.", image: img("#4a6c7a", "Pour-over") },
  { id: 4, name: "Brass Desk Lamp", category: "Lighting", price: 89, desc: "Adjustable arm, warm 2700K bulb included.", image: img("#b08a2e", "Brass Lamp") },
  { id: 5, name: "Wool Throw Blanket", category: "Textiles", price: 74, desc: "Merino wool in a herringbone weave.", image: img("#8c4b4b", "Wool Throw") },
  { id: 6, name: "Oak Wall Shelf", category: "Furniture", price: 64, desc: "Floating shelf with hidden brackets.", image: img("#a67c52", "Oak Shelf") }
];
