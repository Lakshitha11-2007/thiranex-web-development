import { products } from "./data.js";
import { route, start } from "./router.js";
import * as cart from "./cart.js";

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
const money = (n) => `$${n.toFixed(2)}`;
const state = { q: "", cat: "All", sort: "featured" };

const card = (p) => `<article class="card"><a href="#/product/${p.id}"><img src="${p.image}" alt="${esc(p.name)}" loading="lazy" width="400" height="300"></a>
  <h3><a href="#/product/${p.id}">${esc(p.name)}</a></h3><p>${money(p.price)}</p>
  <button data-add="${p.id}">Add to cart</button></article>`;

function grid() {
  let list = products.filter(p => (state.cat === "All" || p.category === state.cat) && p.name.toLowerCase().includes(state.q.toLowerCase()));
  if (state.sort === "low") list.sort((a, b) => a.price - b.price);
  if (state.sort === "high") list.sort((a, b) => b.price - a.price);
  return list.length ? list.map(card).join("") : "<p>No products match. Try a different search.</p>";
}

route("/", () => {
  const cats = ["All", ...new Set(products.map(p => p.category))];
  return `<h1>Shop</h1><div class="tools">
    <label>Search <input id="q" type="search" value="${esc(state.q)}"></label>
    <label>Category <select id="cat">${cats.map(c => `<option ${c === state.cat ? "selected" : ""}>${c}</option>`).join("")}</select></label>
    <label>Sort <select id="sort"><option value="featured">Featured</option><option value="low" ${state.sort==="low"?"selected":""}>Price: low to high</option><option value="high" ${state.sort==="high"?"selected":""}>Price: high to low</option></select></label></div>
    <div class="grid" id="grid">${grid()}</div>`;
});
route("/product/:id", (id) => {
  const p = products.find(x => x.id === +id);
  if (!p) return "<h1>Product not found</h1><a href='#/'>Back to shop</a>";
  return `<a href="#/">&larr; All products</a><div class="detail"><img src="${p.image}" alt="${esc(p.name)}">
    <div><h1>${esc(p.name)}</h1><p>${esc(p.category)}</p><p>${esc(p.desc)}</p><p class="price">${money(p.price)}</p>
    <button data-add="${p.id}">Add to cart</button></div></div>`;
});
route("/cart", () => {
  const rows = cart.items().map(({ id, qty }) => ({ p: products.find(x => x.id === id), qty })).filter(r => r.p);
  if (!rows.length) return "<h1>Your cart</h1><p>Your cart is empty. <a href='#/'>Browse the shop</a>.</p>";
  const total = rows.reduce((s, r) => s + r.p.price * r.qty, 0);
  return `<h1>Your cart</h1><ul class="cart">${rows.map(r => `<li>${esc(r.p.name)} &times; ${r.qty}<span>${money(r.p.price * r.qty)}</span>
    <button data-remove="${r.p.id}">Remove</button></li>`).join("")}</ul><p class="price">Total: ${money(total)}</p>`;
});

const app = $("#app");
const refresh = () => { $("#cart-count").textContent = cart.count(); };
app.addEventListener("click", e => {
  if (e.target.dataset.add) { cart.add(e.target.dataset.add); refresh(); e.target.textContent = "Added"; }
  if (e.target.dataset.remove) { cart.remove(e.target.dataset.remove); refresh(); dispatchEvent(new HashChangeEvent("hashchange")); }
});
app.addEventListener("input", e => {
  if (e.target.id === "q") state.q = e.target.value;
  else if (e.target.id === "cat") state.cat = e.target.value;
  else if (e.target.id === "sort") state.sort = e.target.value;
  else return;
  $("#grid").innerHTML = grid();
});
refresh(); start(app);
