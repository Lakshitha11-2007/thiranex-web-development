// Tiny hash router: seamless navigation with no page reloads.
const routes = [];
export const route = (pattern, handler) => routes.push({ re: new RegExp("^" + pattern.replace(/:\w+/g, "([^/]+)") + "$"), handler });
export function start(outlet) {
  const go = () => {
    const path = location.hash.slice(1) || "/";
    for (const { re, handler } of routes) {
      const m = path.match(re);
      if (m) { outlet.innerHTML = handler(...m.slice(1)); outlet.focus(); window.scrollTo(0, 0); return; }
    }
    outlet.innerHTML = "<h1>Page not found</h1><p><a href='#/'>Back to the shop</a></p>";
  };
  addEventListener("hashchange", go); go();
}
