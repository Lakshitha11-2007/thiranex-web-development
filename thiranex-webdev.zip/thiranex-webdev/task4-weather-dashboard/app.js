"use strict";
// Open-Meteo: free public REST API, no API key needed.
const GEO = "https://geocoding-api.open-meteo.com/v1/search";
const WX = "https://api.open-meteo.com/v1/forecast";
const $ = (s) => document.querySelector(s);
const CODES = { 0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Rime fog",51:"Light drizzle",53:"Drizzle",55:"Heavy drizzle",61:"Light rain",63:"Rain",65:"Heavy rain",71:"Light snow",73:"Snow",75:"Heavy snow",80:"Rain showers",81:"Rain showers",82:"Violent showers",95:"Thunderstorm",96:"Thunderstorm with hail",99:"Thunderstorm with hail" };

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return res.json();
}

async function fetchWeather(city) {
  const geo = await getJSON(`${GEO}?name=${encodeURIComponent(city)}&count=1`);
  if (!geo.results?.length) throw new Error(`No city found for "${city}". Check the spelling.`);
  const { latitude, longitude, name, country } = geo.results[0];
  const params = new URLSearchParams({
    latitude, longitude, timezone: "auto",
    current: "temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code",
    daily: "weather_code,temperature_2m_max,temperature_2m_min", forecast_days: 5
  });
  const data = await getJSON(`${WX}?${params}`);
  return { name, country, data };
}

function render({ name, country, data }) {
  const c = data.current;
  $("#current").innerHTML = `<h2></h2><p class="temp">${Math.round(c.temperature_2m)}°C</p>
    <p>${CODES[c.weather_code] ?? "Unknown conditions"}</p>
    <div class="metrics"><div>Humidity<b>${c.relative_humidity_2m}%</b></div>
    <div>Wind speed<b>${c.wind_speed_10m} km/h</b></div></div>`;
  $("#current h2").textContent = `${name}, ${country}`;
  const d = data.daily;
  $("#forecast").innerHTML = d.time.map((day, i) => `<div><b>${new Date(day).toLocaleDateString(undefined,{weekday:"short"})}</b>
    <p>${Math.round(d.temperature_2m_max[i])}° / ${Math.round(d.temperature_2m_min[i])}°</p>
    <small>${CODES[d.weather_code[i]] ?? ""}</small></div>`).join("");
  $("#current").hidden = $("#forecast").hidden = false;
}

$("#search").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = $("#status"), city = $("#city").value.trim();
  status.className = ""; status.textContent = "Loading…";
  try {
    render(await fetchWeather(city));
    status.textContent = "";
    try { localStorage.setItem("lastCity", city); } catch {}
  } catch (err) {
    $("#current").hidden = $("#forecast").hidden = true;
    status.className = "error";
    status.textContent = err instanceof TypeError ? "Network error. Check your connection and try again." : err.message;
  }
});
try { const last = localStorage.getItem("lastCity"); if (last) { $("#city").value = last; $("#search").requestSubmit(); } } catch {}
