"use strict";
const KEY = "thiranex.tasks";
const $ = (s) => document.querySelector(s);
const list = $("#list");
let tasks = load();
let filter = "all";

function load() { try { return JSON.parse(window.localStorage.getItem(KEY)) || []; } catch { return []; } }
function save() { try { window.localStorage.setItem(KEY, JSON.stringify(tasks)); } catch {} }

function render() {
  list.innerHTML = "";
  const shown = tasks.filter(t => filter === "all" || (filter === "active" ? !t.done : t.done));
  if (!shown.length) list.innerHTML = '<li><span>Nothing here. Add a task above.</span></li>';
  for (const t of shown) {
    const li = document.createElement("li");
    li.dataset.id = t.id;
    li.className = t.done ? "done" : "";
    li.innerHTML = `<input type="checkbox" data-action="toggle" aria-label="Mark done" ${t.done ? "checked" : ""}>
      <span></span>
      <button class="btn" data-action="edit">Edit</button>
      <button class="btn del" data-action="delete" aria-label="Delete task">Delete</button>`;
    li.querySelector("span").textContent = t.text; // textContent prevents XSS
    list.append(li);
  }
  const left = tasks.filter(t => !t.done).length;
  $("#count").textContent = `${left} task${left === 1 ? "" : "s"} left`;
  document.querySelectorAll(".filters button").forEach(b => b.classList.toggle("active", b.dataset.filter === filter));
  save();
}

// CREATE
$("#add-form").addEventListener("submit", e => {
  e.preventDefault();
  const input = $("#new-task"), text = input.value.trim();
  if (!text) return;
  tasks.push({ id: Date.now().toString(), text, done: false });
  input.value = ""; render();
});

// Event delegation: UPDATE / DELETE
list.addEventListener("click", e => {
  const li = e.target.closest("li[data-id]"); if (!li) return;
  const t = tasks.find(x => x.id === li.dataset.id);
  const action = e.target.dataset.action;
  if (action === "delete") tasks = tasks.filter(x => x !== t);
  else if (action === "toggle") t.done = e.target.checked;
  else if (action === "edit") return startEdit(li, t);
  render();
});

function startEdit(li, t) {
  const span = li.querySelector("span");
  const inp = Object.assign(document.createElement("input"), { className: "edit", value: t.text });
  span.replaceWith(inp); inp.focus();
  let done = false;
  const finish = (ok) => { if (done) return; done = true; if (ok && inp.value.trim()) t.text = inp.value.trim(); render(); };
  inp.addEventListener("keydown", e => { if (e.key === "Enter") finish(true); if (e.key === "Escape") finish(false); });
  inp.addEventListener("blur", () => finish(true));
}

document.querySelector(".filters").addEventListener("click", e => {
  if (e.target.dataset.filter) { filter = e.target.dataset.filter; render(); }
});
$("#clear").addEventListener("click", () => { tasks = tasks.filter(t => !t.done); render(); });
render();
