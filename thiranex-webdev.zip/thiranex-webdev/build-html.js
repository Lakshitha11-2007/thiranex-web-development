// Copies index.html into dist/ pointing at the minified assets.
const fs = require("fs");
fs.mkdirSync("dist", { recursive: true });
fs.writeFileSync("dist/index.html", fs.readFileSync("index.html", "utf8"));
console.log("Built dist/");
