# Thiranex Web Development: Quest Log Projects

| Folder | Task | How to run |
|---|---|---|
| task1-semantic-portfolio | HTML5 semantic structure and accessibility | Open `index.html` |
| task2-responsive-css | Grid, Flexbox, media queries, dark mode | Open `index.html` |
| task3-todo-app | JavaScript CRUD, localStorage, filters | Open `index.html` |
| task4-weather-dashboard | Fetch API, async/await, Open-Meteo (no key) | Open `index.html` (needs internet) |
| task5-capstone-catalog | Routing, optimized build, deployment | `cd task5-capstone-catalog && npm install && npm run dev` |

## Before you submit
1. Tasks 1 and 2: replace "Your Name", the image and the email with your own details.
2. Push each folder to GitHub (one repo or five).
3. Tasks 1 to 4: deploy free on GitHub Pages (Settings > Pages) or Netlify Drop.
4. Task 5: import the repo on Vercel or Netlify. The config files are included and run `npm run build`.
5. Paste each live URL and repo URL into the Thiranex "Submit Work" box.
6. Mandatory task: download your offer letter, post on LinkedIn tagging Thiranex, and submit the post URL.
7. Run Chrome DevTools > Lighthouse on Task 1 and fix anything below 100 in Accessibility and SEO.
